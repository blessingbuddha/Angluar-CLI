# `/packages` Folder

This folder is the root of all defined packages in this repository.

Packages that are marked as `private: true` will not be published to NPM.

This folder includes a directory for every scope in NPM, without the `@` sign. Then one folder
per package, which contains the `package.json`.
