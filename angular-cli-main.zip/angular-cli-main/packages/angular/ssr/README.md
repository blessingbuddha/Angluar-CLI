# Angular SSR

Read the dev guide [here](https://angular.io/guide/universal).
